from wsgi import app

#,                         ︵
#                        /'_/) 
#                      /¯ ../ 
#                    /'..../ 
#                  /¯ ../ 
#                /... ./
#   ¸•´¯/´¯ /' ...'/´¯`•¸  
# /'.../... /.... /.... /¯\
#('  (...´.(,.. ..(...../',    \
# \'.............. .......\'.    )      
#   \'....................._.•´/
#     \ ....................  /
#       \ .................. |
#         \  ............... |
#           \............... |
#             \ .............|
#               \............|
#                 \ .........|
#                   \ .......|
#                     \ .....|
#                       \ ...|
#                         \ .|
#                           \\
#                             \('-') 
#   ,,                           |_|\
#                               | |
#FUCKED BY JOBAYAR AHMED @JOBAYAR_AHMED 
#FUCKED BY JOBAYAR AHMED @JOBAYAR_AHMED 
#FUCKED BY JOBAYAR AHMED @JOBAYAR_AHMED 
#FUCKED BY JOBAYAR AHMED @JOBAYAR_AHMED 
#FUCKED BY JOBAYAR AHMED @JOBAYAR_AHMED 
#FUCKED BY JOBAYAR AHMED @JOBAYAR_AHMED 
#FUCKED BY JOBAYAR AHMED @JOBAYAR_AHMED 
